# Easy2FA
A simple, all-in-one 2FA helper for Python — TOTP, QR codes, backup codes, and rate limiting.

## Install
```bash
pip install easy2fa

## USAGE
from easy2fa import Easy2FAAccount

acct = Easy2FAAccount.create(issuer="MyApp", label="user@example.com")
print(acct.current_code())

MIT License

Copyright (c) 2025 Mohammed Amine DAMRI

Permission is hereby granted...